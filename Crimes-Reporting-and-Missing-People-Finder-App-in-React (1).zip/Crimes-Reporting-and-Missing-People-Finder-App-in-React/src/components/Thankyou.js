import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';

export default class Thankyou extends Component {
    render() {
        return (
            <div >
                <h1>Thank You</h1>
                
            </div>
        );
    }
}