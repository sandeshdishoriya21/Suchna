// import { Component, PropTypes } from 'react'
// import { connect } from 'react-redux'
// import { withRouter } from 'react-router'
// //import * as authActionCreators from '../actions/auth'
// import { DBfirebase } from '../database/DBfirebase'

// class LogoutPage extends Component {

//   componentWillMount() {
//     this.props.dispatch(DBfirebase.Logout())
//     this.props.router.replace('/')
//   }

//   render() {
//     return null
//   }
// }
// LogoutPage.propTypes = {
//   dispatch: PropTypes.func.isRequired,
//   router: PropTypes.object.isRequired
// }

// export default connect()(withRouter(LogoutPage))
/*import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';

class Logout extends Component {
    render() {
        return (
            <div className="App">
                <h1>Logged out</h1>
                
            </div>




        );
    }
}

export default Logout;*/
